function Header() {
  return <h1 className="text-2xl font-bold mb-4">To-Do List</h1>;
}

export default Header;
